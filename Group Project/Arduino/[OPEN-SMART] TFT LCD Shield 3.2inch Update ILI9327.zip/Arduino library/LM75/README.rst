====================
LM75 Arduino Library
====================

This library provides an API for LM75 I2C Temperature Sensors.

Installation
============
This library can be downloaded from github at:
    
https://github.com/thefekete/LM75

Just download the and unzip into your arduino library folder, or into the
``libraries`` sub-folder in your sketchbook (for arduino 17 or later).

See ``BasicUsage.pde`` under ``examples/`` for example usage.
